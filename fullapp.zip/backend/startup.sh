#!/bin/bash
# Azure App Service startup script for SnapCloud
# Runs database initialisation then starts gunicorn

cd /home/site/wwwroot/backend

# Initialise database on first run
python -c "from app import init_db; init_db()" 2>&1 | tee -a /home/LogFiles/startup.log

# Start gunicorn
gunicorn --bind=0.0.0.0:$PORT --timeout 120 --workers 2 app:app
